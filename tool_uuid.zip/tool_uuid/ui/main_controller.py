from PyQt6.QtWidgets import QFileDialog, QMessageBox, QHeaderView
from PyQt6.QtCore import Qt

from tool_uuid.models.table_model import DataFrameModel
from tool_uuid.core.transformation_manager import TransformationManager
from tool_uuid.core.script_generator import ScriptGenerator
from tool_uuid.transformation.col_reorder_transformation import ColumnReorderTransformation
from tool_uuid.core.data_loader import load_csv

class MainController:
    def __init__(self, main_window, transformation_manager):
        self.main_window = main_window
        self.manager = transformation_manager
        self._active_row_index = -1
        # 1. Initialize Model
        self.model = DataFrameModel(self.manager.df_wrapper)
        self.main_window.table_view.setModel(self.model)

        # 2. Connect Menu Actions
        self.main_window.action_load.triggered.connect(self.open_csv)
        self.main_window.action_exit.triggered.connect(self.main_window.close)
        self.main_window.action_export.triggered.connect(self.export_script)
        self.main_window.action_undo.triggered.connect(self.undo)
        self.main_window.action_redo.triggered.connect(self.redo)

        # 3. Connect Table View Signals
        self.main_window.table_view.horizontalHeader().sectionClicked.connect(self.on_header_clicked)
        self.main_window.table_view.verticalHeader().sectionClicked.connect(self.on_row_clicked)
        self.main_window.table_view.clicked.connect(self.on_cell_clicked)
        self.main_window.table_view.column_reorder_requested.connect(self.on_column_reorder_drag)

        # 4. Connect Panel Signals
        col_panel = self.main_window.column_options
        col_panel.column_rename.column_rename_request.connect(self.on_column_rename)
        col_panel.encoder_options.column_encoding_request.connect(self.on_encoding_change)
        col_panel.encoder_options.child_rename_request.connect(self.on_column_rename)
        col_panel.column_reorder.column_reorder_request.connect(self.on_manual_reorder)

        cell_panel = self.main_window.cell_options
        cell_panel.cell_edit.cell_change_request.connect(self.on_cell_edit)
        cell_panel.column_rename.column_rename_request.connect(self.on_column_rename)

        row_panel = self.main_window.row_options
        
        self.refresh_view()

    def open_csv(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self.main_window, "Open CSV File", "", "CSV Files (*.csv)"
        )

        if file_path:
            try:
                new_wrapper = load_csv(file_path)
                self.manager = TransformationManager(new_wrapper)
                self.model.update_wrapper(self.manager.df_wrapper)
                self.main_window.set_panel("general")
                self.refresh_view()
            except Exception as e:
                QMessageBox.critical(self.main_window, "Error", f"Failed to load CSV:\n{str(e)}")

    def export_script(self):
        try:
            graph = self.manager.build_dependency_graph()
            generator = ScriptGenerator(graph)
            script_content = generator.generate_script()
            
            file_path, _ = QFileDialog.getSaveFileName(
                self.main_window, "Save Python Script", "cleaning_script.py", "Python Files (*.py)"
            )
            
            if file_path:
                with open(file_path, "w") as f:
                    f.write(script_content)
                QMessageBox.information(self.main_window, "Success", "Script exported successfully!")
        except Exception as e:
            QMessageBox.critical(self.main_window, "Export Error", f"Failed to export script:\n{str(e)}")

    def on_header_clicked(self, logical_index):
        """Switch to Column Panel and populate with correct Parent/Child state."""
        uuid = self.model.get_column_uuid(logical_index)
        if not uuid:
            return

        self.main_window.set_panel("column")
        wrapper = self.manager.df_wrapper
        
        col_name = wrapper.get_col_name_by_uuid(uuid)
        rename_widget = self.main_window.column_options.column_rename
        rename_widget.set_current_column(uuid, col_name)
        rename_widget.uuid = uuid

        # 2. Update Manual Reorder Widget
        reorder_widget = self.main_window.column_options.column_reorder
        reorder_widget.uuid = uuid
        reorder_widget.set_current_index(uuid, str(logical_index))

        # 3. Update Encoding Widget (Parent vs Child Logic)
        is_child = wrapper.uuid_manager.is_child(uuid)
        encoder_widget = self.main_window.column_options.encoder_options
        
        if is_child:
            parent_uuid = wrapper.get_parent_uuid(uuid)
            children_names = {
                c_uuid: wrapper.get_col_name_by_uuid(c_uuid) 
                for c_uuid in wrapper.uuid_manager.get_children_uuids(parent_uuid)
            }
            encoder_widget.set_current_column(parent_uuid, "One-Hot", child_columns=children_names)
        else:
            encoder_widget.set_current_column(uuid, "None")

    def on_row_clicked(self, logical_index):
        """Switch to Row Panel and display index."""
        self.main_window.set_panel("row")
        
        if hasattr(self.main_window.row_options, 'row_index'):
            # The label widget is named 'row_index' in the layout file
            self.main_window.row_options.row_index.setText(f"Row Index: {logical_index}")

    def on_cell_clicked(self, index):
        if not index.isValid():
            return
            
        self.main_window.set_panel("cell")
        
        # Track row for editing
        self._active_row_index = index.row()
        
        uuid = self.model.get_column_uuid(index.column())
        val = self.manager.df_wrapper.get_cell_value(uuid, self._active_row_index)
        col_name = self.manager.df_wrapper.get_col_name_by_uuid(uuid)

        # 1. Update Cell Edit Widget
        if hasattr(self.main_window.cell_options, 'cell_edit'):
            edit_widget = self.main_window.cell_options.cell_edit
            edit_widget.set_current_cell(uuid, str(val))
            edit_widget.uuid = uuid # Ensure widget has UUID for signal

        # 2. Update Rename Widget (in cell panel)
        if hasattr(self.main_window.cell_options, 'column_rename'):
            rename_widget = self.main_window.cell_options.column_rename
            rename_widget.set_current_column(uuid, col_name)
            rename_widget.uuid = uuid # CRITICAL FIX for bug

    def on_column_rename(self, uuid, new_name):
        all_uuids = self.manager.df_wrapper.get_all_uuids()
        
        if uuid in all_uuids:
            col_index = all_uuids.index(uuid)
            self.manager.add_rename(col_index, new_name)
            print(self.manager.df_wrapper.df.columns, flush=True)
            self.refresh_view()
            

    def on_encoding_change(self, uuid, encoding):
        if encoding == "One-Hot":
            all_uuids = self.manager.df_wrapper.get_all_uuids()
            if uuid in all_uuids:
                col_index = all_uuids.index(uuid)
                self.manager.add_onehot(col_index)
                
                self.refresh_view()
                
                # Auto-select result: try to find the first child column
                children = self.manager.df_wrapper.get_children_uuids(uuid)
                if children:
                    new_all_uuids = self.manager.df_wrapper.get_all_uuids()
                    if children[0] in new_all_uuids:
                        # Map UUID back to visual index for the selection handler
                        idx = new_all_uuids.index(children[0])
                        self.on_header_clicked(idx)

    def on_cell_edit(self, uuid, new_value):
        if self._active_row_index != -1:
            self.manager.add_cell_edit(self._active_row_index, uuid, new_value)
            self.refresh_view()

    def on_column_reorder_drag(self, new_uuid_order):
        """Handle Drag & Drop reorder from TableView."""
        self._apply_reorder(new_uuid_order)

    def on_manual_reorder(self, uuid, new_index_str):
        """Handle Manual input reorder from Column Panel."""
        try:
            new_index = int(new_index_str)
            all_uuids = self.manager.df_wrapper.get_all_uuids()
            
            if uuid in all_uuids:
                current_uuids = list(all_uuids)
                # Remove and insert at new position
                current_uuids.remove(uuid)
                
                # Clamp index to bounds
                new_index = max(0, min(new_index, len(current_uuids)))
                current_uuids.insert(new_index, uuid)
                
                self._apply_reorder(current_uuids)
        except ValueError:
            pass # Ignore invalid inputs

    def _apply_reorder(self, new_order):
        # We manually apply this transformation because the manager's 
        # add_column_reorder method in the provided source code contains a syntax error.
        transformation = ColumnReorderTransformation(new_order)
        self.manager.history.append(transformation)
        self.manager.df_wrapper = transformation.apply(self.manager.df_wrapper)
        self.manager.redo.clear()
        
        self.refresh_view()

    def undo(self):
        self.manager.undo_transformation()
        self.refresh_view()

    def redo(self):
        self.manager.redo_transformation()
        self.refresh_view()

    def refresh_view(self):
        """Sync model and UI counters."""
        self.model.update_wrapper(self.manager.df_wrapper)
        
        row_count = self.model.rowCount()
        col_count = self.model.columnCount()
        
        self.main_window.general_options.row_count_label.setText(f"Number of rows: {row_count}")
        self.main_window.general_options.column_count_label.setText(f"Number of columns: {col_count}")